import scapy

# Implement your ICMP receiver here

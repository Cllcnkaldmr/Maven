.. Basic ICMP documentation master file, created by
   sphinx-quickstart on Fri Oct 18 16:20:21 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Basic ICMP Documentation
========================

Please add your names and group ID here by editing `index.rst` in the docs folder.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules
# Coding
You can develop your code in sender and receiver folders. Be careful entire folder is mounted to the `/app` folder in both containers.

The backend folder includes Spring Boot Crud part, and it works via port 8080.

The frontend folder includes Vue.js part, and it works via port 5173. (using Router)

The project will be working with our database, so please make sure you create the database using the SQL file.

It is only a prototype, that is, will be improved time after time.